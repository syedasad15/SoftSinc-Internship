import os
import shutil

FILE_TYPES = {
    "images": [".jpg", ".jpeg", ".png", ".gif"],
    "documents": [".pdf", ".docx", ".txt"],
    "videos": [".mp4", ".mov"],
    "music": [".mp3", ".wav"],
    "archives": [".zip", ".tar", ".gz"]
}

def organize(directory: str):
    try:
        for file in os.listdir(directory):
            file_path = os.path.join(directory, file)
            if os.path.isfile(file_path):
                _, ext = os.path.splitext(file)
                for folder, extensions in FILE_TYPES.items():
                    if ext.lower() in extensions:
                        dest_folder = os.path.join(directory, folder)
                        os.makedirs(dest_folder, exist_ok=True)
                        shutil.move(file_path, os.path.join(dest_folder, file))
                        break
        return "Files organized successfully."
    except Exception as e:
        return f"Error: {e}"