import operator

def calculate(expr: str):
    try:
        ops = {
            '+': operator.add,
            '-': operator.sub,
            '*': operator.mul,
            '/': operator.truediv,
            '**': operator.pow,
            '%': operator.mod,
        }
        for op_symbol in sorted(ops, key=len, reverse=True):
            if op_symbol in expr:
                left, right = map(float, expr.split(op_symbol))
                return ops[op_symbol](left, right)
        return "Unsupported operation"
    except Exception as e:
        return f"Error: {e}"