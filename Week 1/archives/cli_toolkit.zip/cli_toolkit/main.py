import argparse
from calculator import calculate
from organizer import organize
from password_gen import generate

def main():
    parser = argparse.ArgumentParser(description="Modular CLI Toolkit")
    subparsers = parser.add_subparsers(dest="command")

    # Calculator
    calc_parser = subparsers.add_parser("calc", help="Calculator")
    calc_parser.add_argument("expression", type=str, help="Expression to calculate (e.g., 2+2)")

    # File Organizer
    org_parser = subparsers.add_parser("organize", help="File Organizer")
    org_parser.add_argument("directory", type=str, help="Directory to organize")

    # Password Generator
    pwd_parser = subparsers.add_parser("genpass", help="Password Generator")
    pwd_parser.add_argument("--length", type=int, default=12, help="Password length")
    pwd_parser.add_argument("--no-special", action="store_true", help="Exclude special characters")

    args = parser.parse_args()

    if args.command == "calc":
        print(calculate(args.expression))
    elif args.command == "organize":
        print(organize(args.directory))
    elif args.command == "genpass":
        print(generate(length=args.length, use_special=not args.no_special))
    else:
        parser.print_help()

if __name__ == "__main__":
    main()